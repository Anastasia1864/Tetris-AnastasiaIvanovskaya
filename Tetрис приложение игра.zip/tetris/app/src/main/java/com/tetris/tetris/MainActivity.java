package com.tetris.tetris;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button play;
    MediaPlayer mediaPlayer;
    MediaPlayer mediaPlayer2;

    static SharedPreferences SP;
    final static String scoreResult = "0";

    TextView SC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        mediaPlayer = MediaPlayer.create(this, R.raw.sound);
        mediaPlayer2 = MediaPlayer.create(this, R.raw.sound9);
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);
        play = findViewById(R.id.play);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Game.class);
                startActivity(intent);
                mediaPlayer2.start();
            }
        });
        mediaPlayer.start();

        getScore();

    }


    void getScore(){

        SP = getPreferences(MODE_PRIVATE);
        String prefStr = SP.getString(scoreResult, "");


        SC = findViewById(R.id.scoreRecord);
        SC.setText(prefStr);

    }
}
